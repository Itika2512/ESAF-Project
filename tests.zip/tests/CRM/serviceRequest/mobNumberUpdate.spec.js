import { test } from '@playwright/test';
import { LoginPage } from '../../../CRM/login.page';
import { CasaPage } from '../../../CRM/casa360/searchCasa.page';
import { SearchCasaToDetailsPage } from '../../../CRM/casa360/searchToCasaDetails.page';
import { ServiceRequestPage } from '../../../CRM/serviceRequest/servicerequest.page';
import { UpdateMobNumberPage } from '../../../CRM/serviceRequest/srTypes/updateMobNumber.page';
import { SaveSrPage } from '../../../CRM/serviceRequest/saveSr.page';

test('mobile number update', async ({ page }) => {

  const login = new LoginPage(page);
  const casa = new CasaPage(page);
  const casaDetails = new SearchCasaToDetailsPage(page);
  const serviceRequest = new ServiceRequestPage(page);
  const updateMobNumber = new UpdateMobNumberPage(page);
  const saveSr = new SaveSrPage(page);

  await login.login('ESAF_OpsUser1', 'Esaf@2025');
  await casa.searchCasa('260001079');
  await casaDetails.openCasa();
  await serviceRequest.createServiceRequest(
    'CIF', 
    'Personal (PII Data)',
    'Update Mobile Number in CIF', 
    'Test Description', 
    'JMeterDocument.docx'
  );
  await updateMobNumber.createUpdateMobNumberRequest('9999999999');
  await saveSr.saveServiceRequest();
});
