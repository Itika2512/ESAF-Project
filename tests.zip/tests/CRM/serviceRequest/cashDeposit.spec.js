import { test } from '@playwright/test';
import { LoginPage } from '../../../CRM/login.page';

test('cash deposit flow', async ({ page }) => {

  const login = new LoginPage(page);
  // const casa = new CasaPage(page);
});
