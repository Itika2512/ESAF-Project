import { test } from '@playwright/test';
import { LoginPage } from '../../CRM/login.page';
import { searchDepositPage } from '../../CRM/deposits360/searchDeposit.page';
import { searchDepositToDetailsPage } from '../../CRM/deposits360/searchToDepositDetails.page';
import { FinancialDetailsTab } from '../../CRM/deposits360/financialDetails.page';
import { PayoutInstructionsTab } from '../../CRM/deposits360/payout.js';

test('casa search flow', async ({ page }) => {

  const login = new LoginPage(page);
  const searchDeposit = new searchDepositPage(page);
  const searchToDeposit = new searchDepositToDetailsPage(page);
  const financialDetails = new FinancialDetailsTab(page);
  const payoutInstructions = new PayoutInstructionsTab(page);

  await login.login("ESAF_OpsUser1", "Esaf@2025");
  await searchDeposit.searchDeposit("260001508");
  await searchToDeposit.depositDetails();
  await financialDetails.financialDetailsTab();
  await payoutInstructions.payoutTab();
});
