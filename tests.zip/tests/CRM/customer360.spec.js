import { test } from '@playwright/test';
import { LoginPage } from '../../CRM/login.page';
import { SearchCustomerPage } from '../../CRM/customer360/searchCustomer.page';
import { searchCustomerToDetailsPage } from '../../CRM/customer360/searchToCustomerDetails.page';
import { KycInfoTab } from '../../CRM/customer360/kyc.page';
import { CommunicationTab } from '../../CRM/customer360/communication.page';

test('customer360', async ({ page }) => {

  const login = new LoginPage(page);
  const customer = new SearchCustomerPage(page);
  const searchToCustomer = new searchCustomerToDetailsPage(page);
  const communicationTab = new CommunicationTab(page);
  const kycTab = new KycInfoTab(page);

  await login.login("ESAF_OpsUser1", "Esaf@2025");
  await customer.searchCustomer("260001079");
  await searchToCustomer.customerDetails();
  await communicationTab.communicationTab();
  await kycTab.kycTab();
});
