import { test } from '@playwright/test';
import { LoginPage } from '../../CRM/login.page';
import { CasaPage } from '../../CRM/casa360/searchCasa.page';
import { FinancialDetailsTab } from '../../CRM/casa360/financialDetails.page';
import { SearchCasaToDetailsPage } from '../../CRM/casa360/searchToCasaDetails.page';

test('casa search flow', async ({ page }) => {

  const login = new LoginPage(page);
  const casa = new CasaPage(page);
  const financialDetails = new FinancialDetailsTab(page);
  const searchToCasa = new SearchCasaToDetailsPage(page);

  await login.login("ESAF_OpsUser1", "Esaf@2025");
  await casa.searchCasa("260001079");
  await searchToCasa.openCasa();
  await financialDetails.financialDetailsTab();
});
