import { test } from '@playwright/test';
import { LoginPage } from '../demo/login.page';
import { CaseSearch } from '../demo/casa.page';
import { ServiceRequestPage } from '../demo/servicerequest.page';

test.describe.configure({ mode: 'parallel' });

test(`DEMO`, async ({ page }) => {

  const login = new LoginPage(page);
  await login.login('ESAF_OpsUser1', 'Esaf@2025');

  const caseSearch = new CaseSearch(page);
  await caseSearch.searchCasa('260001079');

  const serviceRequest = new ServiceRequestPage(page);
  await serviceRequest.createServiceRequest();

});