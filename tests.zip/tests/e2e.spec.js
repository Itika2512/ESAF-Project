import { test } from '@playwright/test';
import { LoginPage } from '../CRM/login.page';
import { CasaPage } from '../CRM/casa360/casa.page';
import { ServiceRequestPage } from '../CRM/serviceRequest/servicerequest.page';
import { readCSV } from '../utils/csvReader';
import { closeAlertIfPresent } from '../utils/ui.helpers';
import { capturePerformance } from '../utils/performance.helpers';
import { initReport, appendReport } from '../utils/reportWriter';

const users = readCSV('./fixtures/users.csv');

test.describe.configure({ mode: 'parallel' });

initReport();

for (const user of users) {
  test(`E2E - ${user.username}`, async ({ page }) => {

    const login = new LoginPage(page);
    const casa = new CasaPage(page);
    const service = new ServiceRequestPage(page);

    await login.login(user.username, user.password);

    await closeAlertIfPresent(page);

    for (const casaNumber of user.casaNumbers) {
      console.log(`User: ${user.username} | CASA: ${casaNumber}`);

      await casa.searchCasa(casaNumber);

      await closeAlertIfPresent(page);

      const metrics = await capturePerformance(page);

      appendReport({
        username: user.username,
        casaNumber,
        ...metrics
      });

      await service.createServiceRequest(user.filePath);

      await closeAlertIfPresent(page);
    }
  });
}