import { test } from '@playwright/test';
import { LoginPage } from '../../CBS/login.page';
import { taskCodeScreen } from '../../CBS/taskcode.page';
import { CashWithdrawalScreen } from '../../CBS/cashWithdrawal/cashWithdrawal.page';
import { denominationDetailsScreen } from '../../CBS/denominationDetails.page';
import { authorizerSearchScreen } from '../../CBS/authorizerSearch.page';
import { LogoutScreen } from '../../CBS/logoutScreen.page';

test('cash withdrawal flow', async ({ page }) => {
  const login = new LoginPage(page);
  const taskcode = new taskCodeScreen(page);
  const cashWithdrawal = new CashWithdrawalScreen(page);
  const denomination = new denominationDetailsScreen(page);
  const authorizerSearch = new authorizerSearchScreen(page);
  const logout = new LogoutScreen(page);

  await login.login();
  await taskcode.taskCode('1001', 'Cash Withdrawal (1001)');          // from taskCodeScreen
  await cashWithdrawal.cashWithdrawal();    // from CashWithdrawalScreen
  await denomination.denomination();  // from denominationDetailsScreen
  await authorizerSearch.authorizerSearch(); // from authorizerSearchScreen
  await logout.logout();
});
