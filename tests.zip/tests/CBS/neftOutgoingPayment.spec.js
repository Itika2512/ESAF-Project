import { test } from '@playwright/test';
import { LoginPage } from '../../CBS/login.page';
import { taskCodeScreen } from '../../CBS/taskcode.page';
import { NEFToutgoingPaymentInitiationScreen } from '../../CBS/fundsTransfer/neftOutgoingPaymentInitiationScreen.page';
import { OperatingInstructionScreen } from '../../CBS/fundsTransfer/operatingInstructionScreen.page';
import { serviceChargesDetailsScreen } from '../../CBS/fundsTransfer/servicesChargesDetailScreen.page';
import { LogoutScreen } from '../../CBS/logoutScreen.page';

test('NEFT Outgoing Payment Initiation', async ({ page }) => {
  const login = new LoginPage(page);
  const taskcode = new taskCodeScreen(page);
  const neftOutgoingPaymentInitiation = new NEFToutgoingPaymentInitiationScreen(page);
  const operatingInstruction = new OperatingInstructionScreen(page);
  const serviceChargesDetails = new serviceChargesDetailsScreen(page);
  const logout = new LogoutScreen(page);

  await login.login();
  await taskcode.taskCode('2057', 'NEFT Outgoing Payment Initiation (2057)');          // from taskCodeScreen
  await neftOutgoingPaymentInitiation.NEFToutgoingPaymentInitiation();    // from NEFToutgoingPaymentInitiationScreen
  await operatingInstruction.OperatingInstruction();  // from OperatingInstructionScreen
  await serviceChargesDetails.serviceChargesDetails();  // from serviceChargesDetailsScreen
  await logout.logout();
});
