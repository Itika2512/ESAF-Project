import { test } from '@playwright/test';
import { LoginPage } from '../../CBS/login.page';
import { taskCodeScreen } from '../../CBS/taskcode.page';
import { accountBalEnquiryScreen } from '../../CBS/accountBalancesEnquiry/accountBalancesEnquiry.page';
import { accountBalDetailScreen } from '../../CBS/accountBalancesEnquiry/accountBalancesDetail.page';
import { LogoutScreen } from '../../CBS/logoutScreen.page';

test('account balances enquiry', async ({ page }) => {
  const login = new LoginPage(page);
  const taskcode = new taskCodeScreen(page);
  const accountBalEnquiry = new accountBalEnquiryScreen(page);
  const accountBalDetail = new accountBalDetailScreen(page);
  const logout = new LogoutScreen(page);

  await login.login();
  await taskcode.taskCode('7100', 'Accounts Balances Enquiry (7100)');          // from taskCodeScreen
  await accountBalEnquiry.accountBalEnquiry();    // from accountBalEnquiryScreen
  await accountBalDetail.accountBalDetail();  // from accountBalDetailScreen
  await logout.logout();
});
