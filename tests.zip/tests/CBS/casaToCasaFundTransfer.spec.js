import { test } from '@playwright/test';
import { LoginPage } from '../../CBS/login.page';
import { taskCodeScreen } from '../../CBS/taskcode.page';
import { AccountTranferScreen } from '../../CBS/casaToCasaFundTransfer/accountTransferScreen.page';
import { accountDetailScreen } from '../../CBS/casaToCasaFundTransfer/accountDetailScreen.page';
import { authorizerSearchScreen } from '../../CBS/authorizerSearch.page';
import { LogoutScreen } from '../../CBS/logoutScreen.page';

test('casa to casa fund transfer', async ({ page }) => {
  const login = new LoginPage(page);
  const taskcode = new taskCodeScreen(page);
  const accountTranfer = new AccountTranferScreen(page);
  const accountDetail = new accountDetailScreen(page);
  const authorizerSearch = new authorizerSearchScreen(page);
  const logout = new LogoutScreen(page);

  await login.login();
  await taskcode.taskCode('1091', 'CASA to CASA Funds Transfer Request (1091)');          // from taskCodeScreen
  await accountTranfer.accountTransfer();    // from AccountTranferScreen
  await accountDetail.accountDetail();  // from accountDetailScreen
  await authorizerSearch.authorizerSearch(); // from authorizerSearchScreen
  await logout.logout();
});
