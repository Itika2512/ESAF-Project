import { test } from '@playwright/test';
import { LoginPage } from '../../CBS/login.page';
import { taskCodeScreen } from '../../CBS/taskcode.page';
import { cashDepositScreen } from '../../CBS/cashDeposit/cashDeposit.page';
import { denominationDetailsScreen } from '../../CBS/denominationDetails.page';
import { authorizerSearchScreen } from '../../CBS/authorizerSearch.page';
import { LogoutScreen } from '../../CBS/logoutScreen.page';

test('cash deposit flow', async ({ page }) => {
  const login = new LoginPage(page);
  const taskcode = new taskCodeScreen(page);
  const cashDeposit = new cashDepositScreen(page);
  const denomination = new denominationDetailsScreen(page);
  const authorizerSearch = new authorizerSearchScreen(page);
  const logout = new LogoutScreen(page);

  await login.login();
  await taskcode.taskCode('1401', 'Cash Deposit (1401)');          // from taskCodeScreen
  await cashDeposit.cashDeposit();    // from cashDepositScreen
  await denomination.denomination();  // from denominationDetailsScreen
  await authorizerSearch.authorizerSearch(); // from authorizerSearchScreen
  await logout.logout();
});
