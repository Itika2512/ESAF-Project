import { test } from '@playwright/test';
import { LoginPage } from '../../CBS/login.page';
import { taskCodeScreen } from '../../CBS/taskcode.page';
import { RTGSOutgoingPaymentScreen } from '../../CBS/fundsTransfer/rtgsOutgoingPaymentInitiationScreen.page';
import { OperatingInstructionScreen } from '../../CBS/fundsTransfer/operatingInstructionScreen.page';
import { serviceChargesDetailsScreen } from '../../CBS/fundsTransfer/servicesChargesDetailScreen.page';
import { LogoutScreen } from '../../CBS/logoutScreen.page';

test('RTGS Outgoing Payment Initiation', async ({ page }) => {
  const login = new LoginPage(page);
  const taskcode = new taskCodeScreen(page);
  const rtgsOutgoingPayment = new RTGSOutgoingPaymentScreen(page);
  const operatingInstruction = new OperatingInstructionScreen(page);
  const serviceChargesDetails = new serviceChargesDetailsScreen(page);
  const logout = new LogoutScreen(page);

  await login.login();
  await taskcode.taskCode('2055', 'RTGS Outgoing Payment Initiation (2055)');          // from taskCodeScreen
  await rtgsOutgoingPayment.RTGSOutgoingPayment();    // from RTGSOutgoingPaymentScreen
  await operatingInstruction.OperatingInstruction();  // from OperatingInstructionScreen
  await serviceChargesDetails.serviceChargesDetails();  // from serviceChargesDetailsScreen
  await logout.logout();
});
